﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polymorphism
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Person p = new Person();
            p.displayInfo();

            Adam a = new Adam("Adam", "Smith", 25, "Black");
            a.displayInfo();

            Stephan s = new Stephan("Stephan", "Scott", 33, "Dark Brown", "Brown");
            s.displayInfo();
        }
    }
}
