﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polymorphism
{
    class Stephan : Adam
    {
        public string EyeColor { get; set; }

        public Stephan(string firstname, string lastname, int age, string haircolor, string eyecolor)
            :base(firstname, lastname, age, haircolor)
        {
            EyeColor = eyecolor;
        }

        public override void displayInfo()
        {
            MessageBox.Show("       Stephan Derived Class" + "\nFirst Name: " + FirstName + "\nLast Name: " +
                LastName + "\nAge: " + Age + "\nHair Color: " + HairColor + "\nEye Color: " + EyeColor, "Stephan Derived Class");
        }
    }
}
