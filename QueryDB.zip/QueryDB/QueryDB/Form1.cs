﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QueryDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void studentBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.studentBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database1DataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.Student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.database1DataSet.Student);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.studentTableAdapter.FillByMajor(this.database1DataSet.Student);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.studentTableAdapter.FillByStudentID(this.database1DataSet.Student);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.studentTableAdapter.FillByFirstName(this.database1DataSet.Student);
        }
    }
}
