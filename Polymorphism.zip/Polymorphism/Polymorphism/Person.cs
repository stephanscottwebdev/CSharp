﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polymorphism
{
    class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }

        public Person()
        {

        }

        public Person(string firstname, string lastname, int age)
        {
            FirstName = firstname;
            LastName = lastname;
            Age = age;
        }

        public virtual void displayInfo()
        {
            MessageBox.Show("       Person Base Class" + "\nFirst Name: " + FirstName + "\nLast Name: " + LastName + "\nAge: " + Age, "Base Class");
        }
    }
}
