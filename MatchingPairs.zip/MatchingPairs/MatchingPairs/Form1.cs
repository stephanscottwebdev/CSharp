namespace MatchingPairs
{
    public partial class Form1 : Form
    {
        Label firstClicked = null;
        Label secondClicked = null;

        Random random = new Random();
        List<string> icons = new List<string>()
        {
            "!", "!", "N", "N", ",", ",", "k", "k", "b", "b", "v", "v", "w", "w", "z", "z" // List of paired letters to represent the paired icons.
        };
        public Form1()
        {
            InitializeComponent();
            AssignIconsToSquares(); // Loads this method after at program start.
        }

        private void AssignIconsToSquares()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label; // Sets the control to the iconlabel variable.
                if (iconLabel != null)
                {
                    int randomNumber = random.Next(icons.Count); // Takes the count of icons and assigns a random number to each.
                    iconLabel.Text = icons[randomNumber]; // Assigns the random number to the icons/text.

                    iconLabel.ForeColor = iconLabel.BackColor; // Sets the text color to the background color, essentially hiding the icons/text.
                    icons.RemoveAt(randomNumber);
                }
            }
        }

        private void label_click(object sender, EventArgs e) // This method allows the user to show the icons onclick.
        {
            if (timer1.Enabled == true)
            {
                return;
            }

            Label clickedLabel = sender as Label; // Sets the event object sender to the clickedLabel variable so it knows which label was clicked.
            if (clickedLabel != null)
            {
                if (clickedLabel.ForeColor == Color.Black) // Checks if the label clicked has the text color black, if so that means the icon has been clicked.
                    return; // The label has been selected, quit.
                //clickedLabel.ForeColor = Color.Black; // If the text is not black, then the icon has not been clicked, so change it to black.

                if (firstClicked == null)
                {
                    firstClicked = clickedLabel; // Icon has been clicked. 
                    firstClicked.ForeColor = Color.Black; // Turns the icon black to reveal it.

                    return; // Returns the icon.
                }
                secondClicked = clickedLabel;
                secondClicked.ForeColor = Color.Black;

                CheckForWinner();

                if (firstClicked.Text == secondClicked.Text) // Do the icons match?
                {
                    firstClicked = null; // Allow you to start the firstClicked again to continue.
                    secondClicked = null;
                    return;
                }

                timer1.Start(); //After the second label is clicked, the timer will start.
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop(); // Stops the timer.
            firstClicked.ForeColor = firstClicked.BackColor; // Sets color to background so it is invisable.
            secondClicked.ForeColor = secondClicked.BackColor;
            firstClicked = null; // Resets the variable to be clicked again.
            secondClicked = null;
        }

        private void CheckForWinner()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;

                if (iconLabel != null)
                {
                    if (iconLabel.ForeColor == iconLabel.BackColor) // If all the icons are showing the user wins.
                        return;
                }
            }

            MessageBox.Show("You have found all the pairs!", "Congratulations! "); // Displays a message to the user telling them that they won.
            Close();
        }
    }
}