﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstraction
{
    abstract class Animal
    {

        public abstract void eat(); //Meant to be overridden, if you dont, you will get an error.
        public abstract void sound();

        public void sleep()
        {
            MessageBox.Show("Animals sleep!");
        }
    }
}
