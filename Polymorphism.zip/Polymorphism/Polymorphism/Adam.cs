﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polymorphism
{
    class Adam : Person
    {
        public string HairColor { get; set; }

        public Adam(string firstname, string lastname, int age, string haircolor)
            :base(firstname, lastname, age)
        {
            HairColor = haircolor;
        }

        public override void displayInfo()
        {
            MessageBox.Show("       Adam Derived Class" + "\nFirst Name: " + FirstName + "\nLast Name: " + 
                LastName + "\nAge: " + Age + "\nHair Color: " + HairColor, "Adam Derived Class");
        }
    }
}
