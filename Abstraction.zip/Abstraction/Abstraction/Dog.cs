﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstraction
{
    class Dog : Animal
    {
        public override void eat()
        {
            MessageBox.Show("Dogs eat!");
        }

        public override void sound()
        {
            MessageBox.Show("Dogs bark!");
        }

        public void sleep()
        {
            MessageBox.Show("Dogs sleep!");
        }
    }
}
