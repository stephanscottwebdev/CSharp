﻿
using Microsoft.VisualBasic;

string csv;

csv = "1,Stephan,Scott";
//csv = "1,Stephan";
csv = "1,Stephan,Scott,32356 Hunters Run Dr.,Van Meter,IA";
csv = "2,Allison,Scott,32356 Hunters Run Dr.,Van Meter,IA,more,more,more,Married";
csv = "2,Allison,Scott,32356 Hunters Run Dr.,Van Meter,IA,more,more,more,Married,more,more,more,last";

string[] info = csv.Split(separator: ',');

Console.WriteLine(csv);
Console.WriteLine();

// wants to know if there are 3 values "_" states that it has a match but doesnt need to store the value.
//if (info is [var id, _, _,])

// "_" states that it has a match but doesnt need to store the value.
// ".." is zero or more matches. 
if (info is [var id, var firstName, var lastName, var address, var city, var state, .., var last])
{
    Console.WriteLine($"ID: {id}");
    Console.WriteLine($"First Name: {firstName}");
    Console.WriteLine($"Last Name: {lastName}");
    Console.WriteLine($"Address: {address}");
    Console.WriteLine($"City: {city}");
    Console.WriteLine($"State: {state}");
    Console.WriteLine($"Last in list: {last}");
}

// This validates that the id of 1 is called,
//if (info is ["1", var firstName, var lastName, var address, var city, var state, .., var last])
//{
//    Console.WriteLine($"First Name: {firstName}");
//    Console.WriteLine($"Last Name: {lastName}");
//    Console.WriteLine($"Address: {address}");
//    Console.WriteLine($"City: {city}");
//    Console.WriteLine($"State: {state}");
//    Console.WriteLine($"Last in list: {last}");
//}

// This allows id of 1 OR 2,
//if (info is ["1" or "2", var firstName, var lastName, var address, var city, var state, .., var last])
//{
//    Console.WriteLine($"First Name: {firstName}");
//    Console.WriteLine($"Last Name: {lastName}");
//    Console.WriteLine($"Address: {address}");
//    Console.WriteLine($"City: {city}");
//    Console.WriteLine($"State: {state}");
//    Console.WriteLine($"Last in list: {last}");
//}
else
{
    Console.WriteLine("Bad input");
}
